from django.shortcuts import render
from .models import Book
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView

class BookListView(ListView):

    model = Book
    template_name = 'cbvCRUD/listall.html'
    context_object_name = 'books'
    paginate_by = 5
    ordering = ['-number_of_topics']

    # To override and use filter on result of listdata 
    def get_queryset(self):
        qs = super().get_queryset()
        return qs.filter(name__exact='AWS')

    # To add new data and pass it into our template like : here i am passing - me = "vishal Giri".
    def get_context_data(self, **kwargs):
        data = super().get_context_data(**kwargs)
        data['me'] = "Vishal Giri"
        return data


class BookDetailView(DetailView):

    model = Book
    template_name = 'cbvCRUD/detail.html'
    context_object_name = 'book'

class BookCreateView(CreateView):

    model = Book
    fields = ['name','number_of_topics']
    template_name = 'cbvCRUD/create.html'

class BookUpdateView(UpdateView):

    model = Book
    fields = ['name','number_of_topics']
    template_name = 'cbvCRUD/create.html'

class BookDeleteView(DeleteView):

    success_url = "/"
    model = Book
    template_name = 'cbvCRUD/delete.html'
    context_object_name = 'book'


