from django.apps import AppConfig


class CbvcrudConfig(AppConfig):
    name = 'cbvCRUD'
