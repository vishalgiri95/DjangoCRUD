from django.contrib import admin
from django.urls import path
from .views import BookListView, BookDetailView, BookCreateView, BookUpdateView, BookDeleteView


urlpatterns = [
    path("all/", BookListView.as_view(), name = "book-list"),
    path("detail/<int:pk>/", BookDetailView.as_view(), name = "book-detail"),
    path("new/", BookCreateView.as_view(), name = "book-create"),
    path("update/<int:pk>/", BookUpdateView.as_view(), name = "book-update"),
    path("delete/<int:pk>/", BookDeleteView.as_view(), name = "book-delete"),
]
