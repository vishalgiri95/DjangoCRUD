from django.contrib import admin
from django.urls import path
from . import views

app_name = "fbv"

urlpatterns = [
    path('', views.index, name = "index"),
    path('fbv/all/', views.allpost, name = "all-post"),
    path('fbv/new/', views.create, name = "create-post"),
    path('fbv/detail/<int:id>/', views.detail, name = "detail-post"),
    path('fbv/update/<int:id>/', views.update, name = "update-post"),
    path('fbv/delete/<int:id>/', views.delete, name = "delete-post"),

]
