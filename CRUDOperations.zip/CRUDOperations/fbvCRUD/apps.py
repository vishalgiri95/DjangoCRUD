from django.apps import AppConfig


class FbvcrudConfig(AppConfig):
    name = 'fbvCRUD'
