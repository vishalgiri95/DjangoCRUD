from django.shortcuts import render, redirect, get_object_or_404, HttpResponseRedirect
from .forms import PostForm
from .models import Post

def index(request):
    return render(request, "fbvCRUD/index.html")

def allpost(request):
    post = Post.objects.all()
    return render(request, "fbvCRUD/list.html", {"posts": post})


def detail(request, id):
    post = Post.objects.get(id = id)
    return render(request, "fbvCRUD/details.html", {"post":post})



def create(request):

    form = PostForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("fbv:index")
        
    return render(request, "fbvCRUD/create.html", {'form': form})

def update(request, id):
    post = get_object_or_404(Post, id = id)
    form = PostForm(request.POST or None, instance = post)
    if form.is_valid():
        form.save()
        return redirect("fbv:index")
        
    return render(request, "fbvCRUD/create.html", {'form': form})

def delete(request, id):
    print("in side delete")
    post = get_object_or_404(Post, id = id)
    print(post)
    if request.method == "POST":
        print("delete post")
        post.delete()
        return redirect("fbv:all-post")
    return render(request, "fbvCRUD/delete.html", {'post': post})

